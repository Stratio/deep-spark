/*
 * Copyright 2014, Stratio.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.stratio.examples

import com.stratio.deep.context.DeepSparkContext
import com.stratio.deep.config.IDeepJobConfig
import com.stratio.deep.rdd.CassandraRDD
import com.stratio.deep.entity.Cells
import com.stratio.deep.config.DeepJobConfigFactory


object ScalaExample {

	// context properties
	def cluster = "local";
	def jobName = "stratioDeepExample";
	def deepPath = "/opt/stratio/deep";
	def jar = "file:/tmp/MyProject-0.0.1.jar";
	def cassandraHost = "localhost";
	def cassandraPort = 9160;
	def keyspaceName = "test";
	def tableName = "mytable";

	def main(args : Array[String]) {

		val deepContext:DeepSparkContext = new DeepSparkContext(cluster, jobName);

		// Configuration and initialization
		val config = DeepJobConfigFactory.create()
			.host(cassandraHost).rpcPort(cassandraPort)
			.keyspace(keyspaceName).table(tableName)
			.initialize

		// Creating the RDD
		val rdd :CassandraRDD[Cells] = deepContext.cassandraGenericRDD(config)

		val rddCount :Long = rdd.count

		deepContext.stop

		println("Rows in the RDD (ScalaApp): " + rddCount)

		System.exit(0)

	}
}
