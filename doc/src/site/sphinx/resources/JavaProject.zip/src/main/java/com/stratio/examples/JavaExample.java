/*
 * Copyright 2014, Stratio.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.stratio.examples;

import com.stratio.deep.config.DeepJobConfigFactory;
import com.stratio.deep.config.IDeepJobConfig;
import com.stratio.deep.context.DeepSparkContext;
import com.stratio.deep.entity.Cells;
import com.stratio.deep.rdd.CassandraJavaRDD;

public class JavaExample {

	public static void main(String[] args) {

		// context properties
		String cluster = "local";
		String jobName = "stratioDeepExample";
		String deepPath = "/opt/stratio/deep";
		String jar = "file:/tmp/MyProject-0.0.1.jar";
		String cassandraHost = "localhost";
		int cassandraPort = 9160;
		String keyspaceName = "test";
		String tableName = "mytable";

		DeepSparkContext deepContext = new DeepSparkContext(cluster, jobName, deepPath, jar);

		// Configuration and initialization
		IDeepJobConfig config = DeepJobConfigFactory.create()
				.host(cassandraHost).rpcPort(cassandraPort)
				.keyspace(keyspaceName).table(tableName)
				.initialize();

		// Creating the RDD
		CassandraJavaRDD rdd = deepContext.cassandraJavaRDD(config);

		Long rddCount = rdd.count();

		deepContext.stop();

		System.out.println("Rows in the RDD (JavaClass): " + rddCount.toString());

		System.exit(0);

	}

}
